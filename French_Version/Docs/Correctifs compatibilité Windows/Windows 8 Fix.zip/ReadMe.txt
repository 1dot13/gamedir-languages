**************************************************************************************************************************
Si Jagged Alliance 2 v1.13 ne d�marre pas ou est trop lent avec Windows 8, appliquez ce correctif.
**************************************************************************************************************************

1. Copiez le contenu du dossier "GameDir" dans votre r�pertoire d'installation de Jagged Alliance 2 v1.13
2. �ditez le fichier 'Ja2.ini' de votre r�pertoire d'installation de Jagged Alliance 2 v1.13
   -> Mettez PLAY_INTRO = 0, enregistrez le fichier et fermez-le.
3. Faites un clic droit sur l'ex�cutable JA2 1.13 (ja2.exe), modifier les propri�t�s et cochez le mode "compatibilit�"
   -> Cochez le mode de compatibilit� "XP SP3"
4. Passez le mode de couleurs de "Windows 8" � 16 bits
5. Lancez le jeu (ja2.exe) comme administrateur avec Windows 8

R�f�rences :
http://www.ja-galaxy-forum.com/board/ubbthreads.php/topics/312897/Jagged_Alliance_2_on_Windows_8.html
http://www.bears-pit.com/board/ubbthreads.php/topics/315860/Win_8.html#Post315860
